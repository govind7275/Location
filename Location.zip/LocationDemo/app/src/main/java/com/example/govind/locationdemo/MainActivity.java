package com.example.govind.locationdemo;

        import android.content.Intent;
        import android.location.Criteria;
        import android.location.Location;
        import android.location.LocationListener;
        import android.location.LocationManager;
        import android.net.Uri;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.TextView;
        import android.widget.Toast;

public class MainActivity extends AppCompatActivity  implements LocationListener {

    TextView longitude, latitude;
    Button showMap;

    LocationManager locationManager;
    String provider;


    double lat, longi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        latitude = (TextView) findViewById(R.id.latitude);
        longitude = (TextView) findViewById(R.id.longitude);

        showMap = (Button) findViewById(R.id.showMap);
        showMap.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + lat + "," + longi));
                startActivity(i);
            }
        });

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        Criteria criteria = new Criteria();
        provider = locationManager.getBestProvider(criteria, true);

        Toast.makeText(this, "Provider : " + provider, Toast.LENGTH_SHORT).show();

        Location location = locationManager.getLastKnownLocation(provider);

        if(location != null){
            onLocationChanged(location);
        }
        else{
            latitude.setText("Latitude : No Location Found");
            longitude.setText("Longitute : No Location Found");
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        locationManager.requestLocationUpdates(provider, 10000, 1, this);
    }



    @Override
    protected void onPause() {
        super.onPause();
        locationManager.removeUpdates(this);
    }


    @Override
    public void onLocationChanged(Location location) {
        lat = location.getLatitude();
        longi = location.getLongitude();

        latitude.setText("Latitude : " + lat);
        longitude.setText("Longitute : " + longi);
    }

    @Override
    public void onProviderDisabled(String provider) {
        Toast.makeText(this, "Provider Disabled " + provider, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onProviderEnabled(String provider) {
        Toast.makeText(this, "Enabled new provider " + provider, Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }


}
